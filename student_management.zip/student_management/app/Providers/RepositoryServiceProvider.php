<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Data\Repositories\User\EloquentRepository as UserEloquent;
use App\Data\Repositories\User\UserRepository;

use App\Data\Repositories\Student\EloquentRepository as StudentEloquent;
use App\Data\Repositories\Student\StudentRepository;

use App\Data\Repositories\Mark\EloquentRepository as MarkEloquent;
use App\Data\Repositories\Mark\MarkRepository;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(UserRepository::class, UserEloquent::class);
        $this->app->singleton(StudentRepository::class, StudentEloquent::class);
        $this->app->singleton(MarkRepository::class, MarkEloquent::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
