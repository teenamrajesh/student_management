<?php

namespace App\Data\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $guard_name = "web";
    protected $fillable =[
        "name","age","gender","teacher_id"
    ];

    public function teacher()
    {
        return $this->belongsTo(User::class, "teacher_id", "id");
    }
}
