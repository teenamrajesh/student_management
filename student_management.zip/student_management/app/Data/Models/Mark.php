<?php

namespace App\Data\Models;

use Illuminate\Database\Eloquent\Model;

class Mark extends Model
{
    protected $guard_name = "web";
    protected $fillable =[
        "student_id","maths","science","history","term","total"
    ];

    public function student()
    {
        return $this->belongsTo(Student::class, "student_id", "id");
    }
}
