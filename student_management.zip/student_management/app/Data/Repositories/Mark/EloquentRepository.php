<?php

namespace App\Data\Repositories\Mark;

use Auth;
use Illuminate\Support\Facades\Hash;
use App\Data\Models\Mark;
use DB;

/**
 * Class EloquentRepository
 * @package App\Data\Repositories\Mark
 */
class EloquentRepository implements MarkRepository
{

    /**
     *Return All
     */
    public function  all($where = [], $select = [], $first = false)
    {
        if (count($select) == 0) {
            $select = ["*"];
        }

        $obj = Mark::select($select);

        foreach ($where as $key => $value) {
            $obj->where($key, $value);
        }

        if ($first) {
            return $obj->first();
        }

        return $obj->orderBy("id", "asc")->get();
    }

    /**
     * Returns Specific Mark Object By Id
     */
    public function get($id)
    {
        if (is_array($id)) {
            return Mark::whereIn('id', $id)->get();
        } else {
            return Mark::find($id);
        }
    }

    /**
     * Return dummy object
     */
    public function getDummy()
    {
        $obj = new Mark;
        $obj->id = 0;
        $obj->name = null;
        return $obj;
    }

    /**
     * Creates/Update & Return Object
     */
    public function createUpdate(array $data, $id = false)
    {

        if ($id == false) {
            $obj = Mark::create($data);
            
        } else {
            $obj = Mark::find($id);
            if (!is_null($obj)) {
                $obj->update($data);
            }
        }

        return $obj;
    }

   
    /**
     * Deletes object
     */
    public function delete($id)
    {
        return Mark::where("id", $id)->delete();
    }

    /**
     * Returns Datatable
     */
    public function dataTable()
    {
        return Mark::select('*')->with('student');
    }

    
}
