<?php

namespace App\Data\Repositories\User;

use Auth;
use Illuminate\Support\Facades\Hash;
use App\Data\Models\User;
use DB;

/**
 * Class EloquentRepository
 * @package App\Data\Repositories\User
 */
class EloquentRepository implements UserRepository
{

    /**
     *Return All
     */
    public function  all($where = [], $select = [], $first = false)
    {
        if (count($select) == 0) {
            $select = ["*"];
        }

        $obj = User::select($select);

        foreach ($where as $key => $value) {
            $obj->where($key, $value);
        }

        if ($first) {
            return $obj->first();
        }

        return $obj->orderBy("id", "asc")->get();
    }

    /**
     * Returns Specific User Object By Id
     */
    public function get($id)
    {
        if (is_array($id)) {
            return User::whereIn('id', $id)->get();
        } else {
            return User::find($id);
        }
    }

    /**
     * Return dummy object
     */
    public function getDummy()
    {
        $obj = new User;
        $obj->id = 0;
        $obj->name = null;
        return $obj;
    }

    /**
     * Creates/Update & Return Object
     */
    public function createUpdate(array $data, $id = false)
    {

        if (isset($data["password"]) && $data['password'] != "") {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data["password"]);
        }

        if ($id == false) {
            $obj = User::create($data);
            
        } else {
            $obj = User::find($id);
            if (!is_null($obj)) {
                $obj->update($data);
            }
        }

        return $obj;
    }

   
    /**
     * Deletes object
     */
    public function delete($id)
    {
        return User::where("id", $id)->delete();
    }

    /**
     * Returns Datatable
     */
    public function dataTable()
    {
        return User::select('*')->where('role',2);
    }

    public function getUsersByRole($role)
    {
        return User::select('*')->where("role", $role)->get();
    }
}
