<?php

namespace App\Data\Repositories\Student;

/**
 * Interface UserRepository
 * @package App\Data\Repositories\Student
 */
interface StudentRepository
{

    /**
     * Returns users list
     */
    public  function all($where = [], $select = [], $first = false);
    /**
     * Returns Specific User Object By Id
     */
    public function get($id);

    /**
     * Return dummy object
     */
    public function getDummy();

    /**
     * Creates/Update & Return Object
     */
    public function createUpdate(array $data, $id = false);

    /**
     * Deletes object
     */
    public function delete($id);

    /**
     * Returns Datatable
     */
    public function dataTable();

   
}
