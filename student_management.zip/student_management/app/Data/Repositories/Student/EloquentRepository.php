<?php

namespace App\Data\Repositories\Student;

use Auth;
use Illuminate\Support\Facades\Hash;
use App\Data\Models\Student;
use DB;

/**
 * Class EloquentRepository
 * @package App\Data\Repositories\Student
 */
class EloquentRepository implements StudentRepository
{

    /**
     *Return All
     */
    public function  all($where = [], $select = [], $first = false)
    {
        if (count($select) == 0) {
            $select = ["*"];
        }

        $obj = Student::select($select);

        foreach ($where as $key => $value) {
            $obj->where($key, $value);
        }

        if ($first) {
            return $obj->first();
        }

        return $obj->orderBy("id", "asc")->get();
    }

    /**
     * Returns Specific Student Object By Id
     */
    public function get($id)
    {
        if (is_array($id)) {
            return Student::whereIn('id', $id)->get();
        } else {
            return Student::find($id);
        }
    }

    /**
     * Return dummy object
     */
    public function getDummy()
    {
        $obj = new Student;
        $obj->id = 0;
        $obj->name = null;
        return $obj;
    }

    /**
     * Creates/Update & Return Object
     */
    public function createUpdate(array $data, $id = false)
    {

        if ($id == false) {
            $obj = Student::create($data);
            
        } else {
            $obj = Student::find($id);
            if (!is_null($obj)) {
                $obj->update($data);
            }
        }

        return $obj;
    }

   
    /**
     * Deletes object
     */
    public function delete($id)
    {
        return Student::where("id", $id)->delete();
    }

    /**
     * Returns Datatable
     */
    public function dataTable()
    {
        return Student::select('*')->with('teacher');
    }

    
}
