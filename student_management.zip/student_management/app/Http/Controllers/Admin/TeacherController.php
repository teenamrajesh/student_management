<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use DataTables;
use App\Data\Repositories\User\UserRepository;
use Str;

class TeacherController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private static $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        self::$userRepository = $userRepository;
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view("admin.teacher.index");
    }

    /**
     * DataTable Response
     */
    public function result()
    {
        $results = self::$userRepository->dataTable();

        return DataTables::of($results)
        
         
            ->addColumn('edit', function ($result) {
                return "<a href='" . route('teacher.edit', [$result->id]) . "'>
                    <i class='far fa-edit'></i>
                </a>";
            })
            ->addColumn('delete', function ($result) {
                return "<a href='" . route('teacher.destroy', [$result->id]) . "'>
                    <i class='far fa-trash-alt'></i>
                </a>";
            })
        
            ->escapeColumns([])
            ->setRowId('Id')
            ->make(true);
    }
    /**
     *  Create update teacher
     */

    public function createUpdate($user_id = false)
    {
        $user = null;
        
        if ($user_id == false) {
            $user = self::$userRepository->getDummy();
        } else {
            $user = self::$userRepository->get($user_id);
        }
        if (is_null($user)) {
            return redirect()->route('teacher.index')->with('error', 'No such user.');
        }
        return view("admin.teacher.createUpdate")
            ->with("user", $user);
    }
    /**
     * Create /update teacher
     */

    public function createUpdatePost(Request $request)
    {

        $data = $request->all();
        if($data['id']==0)
        {   
            $data["role"] =2;
            $data['email'] = Str::random(10).'@'.Str::random(4).'com';
            $data["password"]= Str::random(10);
            $message = "Created Successfully";
           
        } else {
            $message = "Updated Successfully";
        }

        $user = self::$userRepository->createUpdate($data,$data['id']);

        return redirect()->to(route("teacher.index"))
            ->with('success', $message);
    }

    public function destroy($user_id)
    {
        self::$userRepository->delete($user_id);

        return redirect()->route('teacher.index')->with('success', 'Teacher Deleted.');
    }

}
