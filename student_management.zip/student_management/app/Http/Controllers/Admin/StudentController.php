<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use DataTables;
use App\Data\Repositories\User\UserRepository;
use App\Data\Repositories\Student\StudentRepository;
use Str;

class StudentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private static $userRepository;
    private static $studentRepository;

    public function __construct(UserRepository $userRepository,StudentRepository $studentRepository)
    {
        self::$userRepository = $userRepository;
        self::$studentRepository = $studentRepository;
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view("admin.student.index");
    }

    /**
     * DataTable Response
     */
    public function result()
    {
        $results = self::$studentRepository->dataTable();

        return DataTables::of($results)
            ->addColumn('reporting_teacher', function ($result) {
                return $result->teacher->name;
            })
         
            ->addColumn('edit', function ($result) {
                return "<a href='" . route('student.edit', [$result->id]) . "'>
                    <i class='far fa-edit'></i>
                </a>";
            })
            ->addColumn('delete', function ($result) {
                return "<a href='" . route('student.destroy', [$result->id]) . "'>
                    <i class='far fa-trash-alt'></i>
                </a>";
            })
        
            ->escapeColumns([])
            ->setRowId('Id')
            ->make(true);
    }
    /**
     *  Create update student
     */

    public function createUpdate($user_id = false)
    {
        $user = null;
        $teachers = self::$userRepository->getUsersByRole(2);
        if ($user_id == false) {
            $user = self::$studentRepository->getDummy();
        } else {
            $user = self::$studentRepository->get($user_id);
        }
        if (is_null($user)) {
            return redirect()->route('student.index')->with('error', 'No such user.');
        }
        return view("admin.student.createUpdate")
            ->with("user", $user)
            ->with("teachers", $teachers);
    }
    /**
     * Create /update student
     */

    public function createUpdatePost(Request $request)
    {

        $data = $request->all();
        if($data['id']==0)
        {   
            $message = "Created Successfully";
           
        } else {
            $message = "Updated Successfully";
        }

        $user = self::$studentRepository->createUpdate($data,$data['id']);

        return redirect()->to(route("student.index"))
            ->with('success', $message);
    }

    public function destroy($user_id)
    {
        self::$studentRepository->delete($user_id);

        return redirect()->route('student.index')->with('success', 'Student Deleted.');
    }

}
