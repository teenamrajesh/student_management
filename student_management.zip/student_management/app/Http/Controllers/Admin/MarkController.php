<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use DataTables;
use App\Data\Repositories\User\UserRepository;
use App\Data\Repositories\Student\StudentRepository;
use App\Data\Repositories\Mark\MarkRepository;
use Str;

class MarkController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private static $userRepository;
    private static $studentRepository;
     private static $markRepository;

    public function __construct(UserRepository $userRepository,StudentRepository $studentRepository,MarkRepository $markRepository)
    {
        self::$userRepository = $userRepository;
        self::$studentRepository = $studentRepository;
        self::$markRepository = $markRepository;
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view("admin.mark.index");
    }

    /**
     * DataTable Response
     */
    public function result()
    {
        $results = self::$markRepository->dataTable();

        return DataTables::of($results)
            ->addColumn('name', function ($result) {
                return $result->student->name;
            })
            ->addColumn('created_on', function ($result) {
                return date('M d, Y H:i a',strtotime($result->created_at));
            })
            ->addColumn('edit', function ($result) {
                return "<a href='" . route('mark.edit', [$result->id]) . "'>
                    <i class='far fa-edit'></i>
                </a>";
            })
            ->addColumn('delete', function ($result) {
                return "<a href='" . route('mark.destroy', [$result->id]) . "'>
                    <i class='far fa-trash-alt'></i>
                </a>";
            })
        
            ->escapeColumns([])
            ->setRowId('Id')
            ->make(true);
    }
    /**
     *  Create update student
     */

    public function createUpdate($mark_id = false)
    {
        $mark = null;
        $students = self::$studentRepository->all([],[],false);
        if ($mark_id == false) {
            $mark = self::$markRepository->getDummy();
        } else {
            $mark = self::$markRepository->get($mark_id);
        }
        if (is_null($mark)) {
            return redirect()->route('mark.index')->with('error', 'No such mark.');
        }
        return view("admin.mark.createUpdate")
            ->with("mark", $mark)
            ->with("students", $students);
    }
    /**
     * Create /update student
     */

    public function createUpdatePost(Request $request)
    {

        $data = $request->all();
        $data['total'] = $data['maths'] + $data['science'] + $data['history'];
        if($data['id']==0)
        {   
            $message = "Created Successfully";
           
        } else {
            $message = "Updated Successfully";
        }

        $user = self::$markRepository->createUpdate($data,$data['id']);

        return redirect()->to(route("mark.index"))
            ->with('success', $message);
    }

    public function destroy($mark_id)
    {
        self::$markRepository->delete($mark_id);

        return redirect()->route('mark.index')->with('success', 'Mark Deleted.');
    }

}
